# Guia de Testes — Gerenciamento de Competições de Corridas

Manual para testar o sistema localmente, entender o que dá para fazer no HTML e como verificar tudo pelo console do navegador.
Também serve como base para git push/pull e para o próximo membro do grupo continuar o trabalho.

---

## 1. Como rodar o projeto

O projeto usa **ES Modules** (`import`/`export`) e **`fetch`**. Por isso, **não abra o `index.html` com duplo clique** (protocolo `file://`). Use um servidor local:

- **VS Code + extensão Live Server:** clique com o botão direito em `index.html` → *Open with Live Server*.
- **Ou** qualquer servidor simples (ex.: `python -m http.server 5500` na raiz do projeto) e abra `http://localhost:5500`.

> Não é preciso Python/Node para o site funcionar — o Live Server já é um servidor. Python/Node só são necessários se quiser usar a alternativa acima.

Abra o **Console do navegador** com `F12` → aba *Console*. Todos os resultados também aparecem na área `<pre id="saida">` da página.

---

## 2. Como o código funciona (visão geral)

Arquitetura **MVC**, igual ao diagrama de classes:

```
js/
  models/      → classes (dados + regras) do diagrama
    comp.js       Competicao (superclasse)
    marat.js      Maratona extends Competicao
    trail.js      TrailRunning extends Competicao
    atleta.js     Atleta
  controllers/ → operações sobre as listas (CRUD + filtros)
    atletaControl.js   AtletaController
    compControl.js     CompeticaoController
  views/
    view.js      View (lê os campos do HTML e escreve a saída)
  script.js     Ponto de entrada (liga View → Controllers, cuida de JSON/localStorage e validações)
index.html      Formulário único com todos os campos e botões
data/dados.json Dados iniciais (carregados na primeira execução)
```

**Fluxo de dados:** `index.html` (botão) → `script.js` (listener + validação) → `view.js` (lê campos) → `controller` (executa a operação) → `model` (objeto criado) → `view.js` (mostra o resultado na tela e no console) → `localStorage` (persiste).

**Persistência:** na 1ª execução o `script.js` lê `data/dados.json` e grava no `localStorage`. Depois disso, sempre lê do `localStorage`. Para voltar aos dados originais: apague `atletas` e `competicoes` do localStorage (comando no item 6) e recarregue.

**ID automático:** o `id` **não** está no formulário. Ele é gerado no momento do cadastro com `Date.now()` (milissegundos desde 1970 → 13 dígitos).

---

## 3. Conformidade com o diagrama e o PDF

| Item do diagrama/PDF | Onde está no código | Status |
|---|---|---|
| Classe `Atleta` com id, idade, cpf, nome, contato, modalidade, peso | `js/models/atleta.js` | OK |
| Classe `Competicao` (superclasse) com id, horario, data, nome, local, distancia, altimetria | `js/models/comp.js` | OK |
| Classe `Maratona` (subclasse) com objetivo, fechamentoVias, pontosHidratacao | `js/models/marat.js` | OK |
| Classe `TrailRunning` (subclasse) com checkPoint, grauDificuldade, climaEsperado | `js/models/trail.js` | OK |
| `AtletaController`: cadastrar / buscar / atualizar / remover / filtrarPorModalidade / toString | `js/controllers/atletaControl.js` | OK |
| `CompeticaoController`: cadastrar / buscar / atualizar / remover / filtrarPorTipo / toString | `js/controllers/compControl.js` | OK |
| Encapsulamento (campos privados `#`), herança, sobrescrita de `toString()`, polimorfismo | models | OK |
| Carregar JSON na 1ª vez e persistir no localStorage | `js/script.js` (`carregar`/`salvar`) | OK |
| **Inscrição** (tabela/controller) aparece **só no PNG**, não no código | — | Não implementado (correto) |

> Observação: o diagrama cita a entidade **Inscrição**, mas por orientação dos professores ela existe **apenas no diagrama**, e o código **não** deve ter model nem controller de Inscrição.

---

## 4. O que dá para fazer no HTML (e o que testar)

A página tem **um formulário** com 4 blocos:

**Bloco "Atleta"** — campos: `atletaIdade`, `atletaCpf`, `atletaNome`, `atletaContato`, `atletaModalidade` (Maratona / Trail Running), `atletaPeso`.

**Bloco "Competição"** — campos: `tipo` (Maratona / TrailRunning), `compHorario`, `compData`, `compNome`, `compLocal`, `compDistancia`, `compAltimetria` e os campos específicos:
- Maratona: `compObjetivo`, `compFechamentoVias`, `compPontosHidratacao`
- TrailRunning: `compCheckPoint`, `compGrauDificuldade`, `compClimaEsperado`
> Só preencha os campos do `tipo` escolhido. Os outros ficam como `undefined`/`NaN` e não aparecem no `toString` da subclasse.

**Bloco "Atleta — operações"** — campo `atletaId` + botões: `cadastrarAtleta`, `buscarAtleta`, `atualizarAtleta`, `removerAtleta`, `filtrarPorModalidade`, `listarAtletas`.

**Bloco "Competição — operações"** — campo `compId` + botões: `cadastrarCompeticao`, `buscarCompeticao`, `atualizarCompeticao`, `removerCompeticao`, `filtrarPorTipo`, `listarCompeticoes`.

### Passo a passo (teste manual pela tela)

1. Abra a página (Live Server). A saída deve mostrar: `Carregados 4 atletas e 4 competições`.
2. **Filtrar atletas:** escolha `Trail Running` em *Atleta → modalidade* e clique `filtrarPorModalidade` → aparecem 2 atletas (Carla, Diego).
3. **Filtrar competições:** escolha `TrailRunning` em *tipo* e clique `filtrarPorTipo` → aparecem 2 competições.
4. **Buscar atleta:** digite `2` em *id do atleta* e clique `buscarAtleta` → mostra o Bruno Lima. Digite `99` → `Atleta não encontrado`.
5. **Cadastrar atleta (id automático):** preencha os campos do bloco Atleta e clique `cadastrarAtleta` → a lista passa de 4 para 5 e o último item tem um `id` de 13 dígitos.
6. **Buscar/atualizar/remover com o id novo:** copie o id gerado, cole em *id do atleta*, altere um campo e clique `atualizarAtleta` (o id não muda) e depois `removerAtleta` (volta para 4).
7. **Cadastrar competição:** escolha `TrailRunning`, preencha os campos de trilha, clique `cadastrarCompeticao` → aparece um `TrailRunning{Competicao{...}}`.
8. **Listar (toString/polimorfismo):** clique `listarCompeticoes` → aparecem `Maratona{...}` e `TrailRunning{...}` na mesma lista.

---

## 5. Validações (dados proibidos)

As regras ficam em `js/script.js` (funções `validarAtleta` e `validarCompeticao`, chamadas no cadastrar e no atualizar). Se algo estiver errado, a operação é **bloqueada** e a mensagem aparece na saída.

**Atleta:**
- Nome obrigatório e **sem números**.
- Idade **não pode ser negativa**.
- Peso **não pode ser negativo**.
- CPF **obrigatório**, com **exatamente 11 dígitos** (aceita com ou sem máscara: `00000000000` ou `000.000.000-00`) e **não pode repetir** em outro atleta.
- **id repetido** é bloqueado (o id é `Date.now()`, então colisão é praticamente impossível, mas o guard existe).

**Competição:**
- Nome obrigatório.
- Distância e altimetria **não podem ser negativas**.
- Pontos de hidratação (Maratona) **não podem ser negativos**.
- **id repetido** é bloqueado.

**Atualizar** também valida os dados e exige que o id exista (senão mostra "não encontrado").

### Como testar as validações pela tela
1. Preencha *idade* com `-5` e clique `cadastrarAtleta` → `A idade não pode ser negativa` (nada é cadastrado).
2. Nome com número (ex.: `Jo4o`) → `O nome do atleta não pode conter números`.
3. CPF igual ao de um atleta já cadastrado (ex.: `111.111.111-11`) → `Já existe um atleta com esse CPF`.
4. CPF com menos/mais de 11 dígitos (ex.: `999` ou `1234567890123`) → `O CPF deve ter 11 dígitos (ex.: 000.000.000-00)`.
5. Distância `-10` → `A distância não pode ser negativa`.

---

## 6. Como testar pelo console

Com a página aberta (`F12` → Console), execute os comandos abaixo. Eles usam a mesma lógica dos botões.

```js
// 1. Ver o que está salvo no localStorage
localStorage.getItem("atletas");
localStorage.getItem("competicoes");

// 2. Simular um clique em qualquer botão (dispara o mesmo handler da tela)
document.querySelector("#listarAtletas").click();
document.querySelector("#filtrarCompeticoes").click();

// 3. Cadastrar um atleta digitando valores direto nos campos + clique
document.querySelector("#atletaIdade").value = 30;
document.querySelector("#atletaCpf").value = "000.000.000-00";
document.querySelector("#atletaNome").value = "Teste Console";
document.querySelector("#atletaContato").value = "0000";
document.querySelector("#atletaModalidade").value = "Maratona";
document.querySelector("#atletaPeso").value = 70;
document.querySelector("#cadastrarAtleta").click();

// 4. Testar uma validação (idade negativa deve ser bloqueada)
document.querySelector("#atletaIdade").value = -5;
document.querySelector("#cadastrarAtleta").click();

// 5. Testar o CPF (menos de 11 dígitos deve ser bloqueado)
document.querySelector("#atletaIdade").value = 30;
document.querySelector("#atletaCpf").value = "999";
document.querySelector("#cadastrarAtleta").click();

// 6. Ler o resultado exibido na tela
document.querySelector("#saida").textContent;

// 7. Apagar os dados salvos e recarregar (volta ao dados.json)
localStorage.removeItem("atletas");
localStorage.removeItem("competicoes");
location.reload();
```

> Importante: as instâncias dos controllers vivem dentro do módulo `script.js` e **não** ficam expostas no `window`. Ou seja, no console você interage pela **interface** (campos + `click()`), não chamando os controllers direto. Todos os resultados vão para `#saida` e para o `console.log` via `view.mostrar()`.

---

## 7. Checklist rápido de validação

- [ ] A página carrega e mostra `Carregados 4 atletas e 4 competições`.
- [ ] Os campos no `localStorage` (`atletas`, `competicoes`) são criados na 1ª execução.
- [ ] Filtrar atletas por modalidade retorna apenas os da modalidade certa.
- [ ] Filtrar competições por tipo retorna apenas Maratona ou apenas TrailRunning.
- [ ] `buscarAtleta`/`buscarCompeticao` com id inexistente mostram mensagem de "não encontrado".
- [ ] Cadastrar gera `id` de 13 dígitos (Date.now) e não duplica.
- [ ] Atualizar mantém o mesmo id e não duplica o registro.
- [ ] Remover tira exatamente 1 registro.
- [ ] `toString` mostra o formato `Classe{...}` e as subclasses dentro de `Competicao{...}`.
- [ ] Idade/peso/distância/altimetria/pontos negativos são bloqueados.
- [ ] Nome com número e CPF repetido são bloqueados.
- [ ] CPF com menos/mais de 11 dígitos é bloqueado.
- [ ] Após `F5`, os dados cadastrados permanecem (localStorage).

---

## 8. Dicas para o próximo membro (git)

1. `git pull` para pegar a versão mais recente.
2. Rodar com **Live Server** (não abrir por `file://`).
3. Antes de `git push`: conferir que `js/`, `css/`, `data/` e `index.html` estão salvos e que a página carrega sem erros no Console (`F12`).
4. Não versionar pastas geradas pela IDE (ex.: `.screenshots`, `.trae-html-share-packages`); se apareçam, adicione ao `.gitignore`.
